package com.example.mama.logyus;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;



public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.SearchViewHolder> {
    Context context;
    ArrayList<String> title;
    ArrayList<String> image;

    class SearchViewHolder extends RecyclerView.ViewHolder{

        ImageView imgView;
        TextView textView;
        Button buttonReview;

        public SearchViewHolder(View itemView) {
            super(itemView);
            imgView = itemView.findViewById(R.id.book_img);
            textView = itemView.findViewById(R.id.book_txt);
            buttonReview=itemView.findViewById(R.id.buttonwriteReview);
        }
    }

    public SearchAdapter(Context context, ArrayList<String> title, ArrayList<String> image) {
        this.context = context;
        this.title = title;
        this.image = image;
    }

    @Override
    public SearchAdapter.SearchViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.search_book, parent, false);
        return new SearchAdapter.SearchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SearchViewHolder holder, final int position) {

        holder.textView.setText(title.get(position));


        //Glide.with(context).load(image.get(position)).fitCenter().placeHolder(R.mipmap.ic_launcher_round).into(holder.imgView);
        Glide.with(context).load(image.get(position))
                .into(holder.imgView);

        holder.buttonReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(context,PostEventActivity.class);
                i.putExtra("title",title.get(position));
                i.putExtra("image",image.get(position));
                context.startActivity(i);

            }
        });

    }


    @Override
    public int getItemCount() {
        return title.size();
    }
}
